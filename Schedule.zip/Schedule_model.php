<?php

class Schedule_model extends CI_Model {

	private $id;
	private $errors = [];
	private $schedules = [];

	public function __construct() {
		$this->load->database();

		$result = $this->db->query('SELECT id, `date`, meetingtime, task FROM schedule');

		$this->schedules = $result->result();

	}

	public function get_schedule() {
		return $this->schedules;
	}
}