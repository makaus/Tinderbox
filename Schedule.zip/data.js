var date;
var meetingtime;
var task;
var id;
var TinderboxEvents = {'TODAY' : '<span>Today</span>',};

function getSchedule() {
	jQuery.ajax({
		url: 'http://localhost:8888/tinderbox/schedule',
		contentType: 'application/json',
		type: 'GET',
		async: false,
		success: function(data, status, response) {
			console.log(data);
			for(var i in data) {
				id = data[i].id;
				date = data[i].date;
				var dateExploded = date.split('-');
				var dateNumber = dateExploded[1];
				dateNumber = parseInt(dateNumber);
				function nth(d) {
				  if(d>3 && d<21) return 'th'; // thanks kennebec
				  switch (d % 10) {
				        case 1:  return "st";
				        case 2:  return "nd";
				        case 3:  return "rd";
				        default: return "th";
				    }
				} 
				meetingtime = data[i].meetingtime;
				task = data[i].task;
				
				TinderboxEvents[date] = '<span id="container-date"><span class="left-text-span">' + dateNumber + '' + nth(dateNumber) +'</span><span class="text-right-span"><ul class="list-group"><li class="list-group-item date">Meeting time: ' + meetingtime +'</li><li class="list-group-item date">Task: ' + task + '</li></ul></span></span>';
			}
		},
		error: function(request, status, error) {
			console.log(request);
		}
	});
	return TinderboxEvents;
};
